import React from "react";


function Footer() {
  return (
    <footer className="app-footer">
      <p>© {new Date().getFullYear()} NASA API Explorer | Projekt edukacyjny</p>
    </footer>
  );
}

export default Footer;