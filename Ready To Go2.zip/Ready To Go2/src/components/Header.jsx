import React from "react";
import "./../scss/components/_header.scss";

function Header() {
  return (
    <header className="nasa-header">
      <img src="/Nasa_logo.png" alt="NASA Logo" className="nasa-logo" />

    </header>
  );
}

export default Header;