import React from "react";

function MarsImage({ image }) {
  return (
    <div className="mars-images__item">
      <img src={image.img_src} alt={`Mars Rover ${image.id}`} />
      <div className="mars-images__info">
        <p><strong>ID:</strong> {image.id}</p>
        <p><strong>Sol:</strong> {image.sol}</p>
        <p><strong>Data ziemska:</strong> {image.earth_date}</p>
        <p><strong>Kamera:</strong> {image.camera.name} ({image.camera.full_name})</p>
        <p><strong>Łazik:</strong> {image.rover.name}</p>
        <p><strong>Status:</strong> {image.rover.status}</p>
      </div>
    </div>
  );
}

export default MarsImage;