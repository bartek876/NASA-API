import React from "react";

function EarthImage({ imageUrl, lat, lon, date, dim }) {
  return (
    <div className="earth-image">
      <img src={imageUrl} alt={`Zdjęcie Ziemi ${date}`} />
      <div className="earth-image__info">
        <p><strong>Data:</strong> {date}</p>
        <p><strong>Szerokość:</strong> {lat}</p>
        <p><strong>Długość:</strong> {lon}</p>
        <p><strong>Rozmiar (dim):</strong> {dim}</p>
      </div>
    </div>
  );
}

export default EarthImage;