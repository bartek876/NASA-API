function Episode(props) {
  return (
    <div>
      <p>id: {props.id}</p>
      <p>name: {props.name}</p>
      <p>episodes: {props.episodes}</p>
    </div>
  );
}

export default Episode;
