import React, { useState, useEffect } from "react";
import APOD from "./APOD";

function APODS({ apiKey }) {
  const [apods, setApods] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      let url = `https://api.nasa.gov/planetary/apod?api_key=${apiKey || "DEMO_KEY"}&count=5`;
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        setApods(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [apiKey]);

  return (
    <div className="apods-container">
      <h2 className="apods-header">NASA APODs</h2>

      {/* Możesz tu dodać formularz do ustawiania count, startDate, endDate itp. */}

      {error && <p className="error-message">{error}</p>}
      {loading && <p className="loading-message">Ładowanie...</p>}

      {!loading && !error && apods.length > 0 && (
        <div className="apods-list">
          {apods.map((item, i) => (
            <APOD key={i} item={item} />
          ))}
        </div>
      )}

      {!loading && !error && apods.length === 0 && <p>Brak danych do wyświetlenia.</p>}
    </div>
  );
}

export default APODS;