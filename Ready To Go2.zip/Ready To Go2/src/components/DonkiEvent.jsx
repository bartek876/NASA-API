import React from "react";

function DonkiEvent({ event }) {
    return (
        <div className="donki__item">
            <p><strong>ID:</strong> {event.activityID}</p>
            <p><strong>Początek:</strong> {event.startTime}</p>
            <p><strong>Lokalizacja źródła:</strong> {event.sourceLocation || "Nieznana"}</p>
            <p><strong>Notatka:</strong> {event.note || "Brak"}</p>
            <p><strong>Instrumenty:</strong> {event.instruments?.map(i => i.displayName).join(", ")}</p>
        </div>
    );
}

export default DonkiEvent;