import React, { useState, useEffect } from "react";
import MarsImage from "./MarsImage";

const apiKey = "COpeT8kGhXL3b8hntiU6r1Ro59JRfMapmppokL13";

function MarsImages() {
  const [images, setImages] = useState([]);
  const [sol, setSol] = useState(1000);
  const [camera, setCamera] = useState("");
  const [page, setPage] = useState(1);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchImages = () => {
    const url = `https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=${sol}&${camera ? `camera=${camera}&` : ""}page=${page}&api_key=${apiKey}`;

    setLoading(true);
    setError(null);

    fetch(url)
      .then((res) => res.json())
      .then((data) => setImages(data.photos))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchImages();
  }, []);

  return (
    <div className="mars-images">
      <h2>Zdjęcia Mars Rover (Curiosity)</h2>

      <form
        className="mars-images__form"
        onSubmit={(e) => {
          e.preventDefault();
          fetchImages();
        }}
      >
        <label>
          Sol:
          <input type="number" value={sol} onChange={(e) => setSol(e.target.value)} min="0" />
        </label>

        <label>
          Kamera:
          <select value={camera} onChange={(e) => setCamera(e.target.value)}>
            <option value="">Wszystkie</option>
            <option value="FHAZ">FHAZ</option>
            <option value="RHAZ">RHAZ</option>
            <option value="MAST">MAST</option>
            <option value="CHEMCAM">CHEMCAM</option>
            <option value="NAVCAM">NAVCAM</option>
            <option value="MAHLI">MAHLI</option>
            <option value="MARDI">MARDI</option>
          </select>
        </label>

        <label>
          Strona:
          <input type="number" value={page} onChange={(e) => setPage(e.target.value)} min="1" />
        </label>

        <button type="submit">Szukaj</button>
      </form>

      {error && <p className="error">{error}</p>}
      {loading && <p className="loading">Ładowanie...</p>}

      <div className="mars-images__list">
        {images.length === 0 && !loading && <p>Brak zdjęć do wyświetlenia.</p>}
        {images.map((img) => (
          <MarsImage key={img.id} image={img} />
        ))}
      </div>
    </div>
  );
}

export default MarsImages;