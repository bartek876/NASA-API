import React, { useEffect, useState } from "react";
import DonkiEvent from "./DonkiEvent";

const API_URL = "https://api.nasa.gov/DONKI/CME";
const DEMO_KEY = "DEMO_KEY";

export default function DonkiEvents() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch(`${API_URL}?startDate=2025-05-01&endDate=2025-05-28&api_key=${DEMO_KEY}`)
            .then(res => {
                if (!res.ok) throw new Error("Błąd podczas pobierania danych");
                return res.json();
            })
            .then(data => {
                if (!Array.isArray(data)) throw new Error("Niepoprawny format danych");
                setEvents(data);
            })
            .catch(err => setError(err.message))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <p>Ładowanie...</p>;
    if (error) return <p>Błąd: {error}</p>;
    if (events.length === 0) return <p>Brak zdarzeń w tym okresie.</p>;

    return (
        <div className="donki-events">
            {events.map(event => (
                <DonkiEvent key={event.activityID || event.messageID || Math.random()} event={event} />
            ))}
        </div>
    );
}

