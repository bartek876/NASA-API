import React, { useEffect, useState } from "react";
import EarthImage from "./EarthImage";

const apiKey = "DEMO_KEY"; // ← zamień na swój klucz z https://api.nasa.gov

function getRandomCoord(min, max) {
  return (Math.random() * (max - min) + min).toFixed(2);
}

function getRandomDate() {
  const start = new Date(2019, 0, 1).getTime();
  const end = new Date(2023, 11, 31).getTime();
  return new Date(start + Math.random() * (end - start))
    .toISOString()
    .split("T")[0];
}

function EarthImages() {
  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchImages = async () => {
      const imagesList = [];
      for (let i = 0; i < 3; i++) {
        const lat = getRandomCoord(-60, 60);
        const lon = getRandomCoord(-180, 180);
        const date = getRandomDate();
        const dim = "0.1";
        const url = `https://api.nasa.gov/planetary/earth/imagery?lon=${lon}&lat=${lat}&date=${date}&dim=${dim}&api_key=${apiKey}`;

        try {
          const res = await fetch(url);
          if (res.ok) {
            imagesList.push({ lat, lon, date, dim, imageUrl: url });
            setImages([...imagesList]);
          }
        } catch {
          continue;
        }
      }
    };

    fetchImages();
  }, []);

  return (
    <div className="earth-images">
      <h2>Zdjęcia Ziemi (NASA Earth Imagery)</h2>
      {images.length === 0 ? (
        <p>Ładowanie zdjęć...</p>
      ) : (
        <div className="earth-images__grid">
          {images.map((img, i) => (
            <EarthImage key={i} {...img} />
          ))}
        </div>
      )}
    </div>
  );
}

export default EarthImages;