import React, { useState } from "react";


const questions = [
    {
        question: "Która planeta jest największa w Układzie Słonecznym?",
        options: ["Ziemia", "Jowisz", "Mars", "Saturn"],
        answer: "Jowisz",
    },
    {
        question: "Jak nazywa się najbliższa Ziemi gwiazda?",
        options: ["Proxima Centauri", "Sirius", "Słońce", "Polarna"],
        answer: "Słońce",
    },
    {
        question: "Co to jest czarna dziura?",
        options: [
            "Rodzaj planety",
            "Miejsce z nieskończoną grawitacją",
            "Gwiazda",
            "Asteroida",
        ],
        answer: "Miejsce z nieskończoną grawitacją",
    },
    {
        question: "Jaka agencja odpowiada za program Artemis?",
        options: ["ESA", "NASA", "CNSA", "SpaceX"],
        answer: "NASA",
    },
];

export default function Quiz() {
    const [current, setCurrent] = useState(0);
    const [score, setScore] = useState(0);
    const [showResult, setShowResult] = useState(false);

    const handleAnswer = (option) => {
        if (option === questions[current].answer) setScore(score + 1);
        const next = current + 1;
        if (next < questions.length) {
            setCurrent(next);
        } else {
            setShowResult(true);
        }
    };

    return (
        <div className="quiz">
            <h2>🚀 Quiz o Kosmosie</h2>
            {showResult ? (
                <div className="result">
                    <p>
                        Twój wynik: {score}/{questions.length}
                    </p>
                </div>
            ) : (
                <div className="question">
                    <p>{questions[current].question}</p>
                    <div className="options">
                        {questions[current].options.map((opt, i) => (
                            <button key={i} onClick={() => handleAnswer(opt)}>
                                {opt}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}