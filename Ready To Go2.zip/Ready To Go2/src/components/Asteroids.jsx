import React, { useEffect, useState } from "react";
import Asteroid from "./Asteroid";

const apiKey = "DEMO_KEY";

function Asteroids() {
    const [asteroids, setAsteroids] = useState([]);

    useEffect(() => {
        const fetchAsteroids = async () => {
            const today = new Date().toISOString().split("T")[0];

            const url = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${today}&end_date=${today}&api_key=${apiKey}`;

            try {
                const res = await fetch(url);
                const data = await res.json();
                const neoToday = data.near_earth_objects[today];

                const parsed = neoToday.map((ast) => ({
                    name: ast.name,
                    diameter: Math.round(ast.estimated_diameter.meters.estimated_diameter_max),
                    speed: Math.round(
                        ast.close_approach_data[0].relative_velocity.kilometers_per_hour
                    ),
                    distance: Math.round(
                        ast.close_approach_data[0].miss_distance.kilometers
                    ),
                    hazardous: ast.is_potentially_hazardous_asteroid,
                }));

                setAsteroids(parsed);
            } catch (err) {
                console.error("Błąd przy pobieraniu danych o asteroidach:", err);
            }
        };

        fetchAsteroids();
    }, []);

    return (
        <div className="asteroids">
            <h2 className="asteroids__title">Asteroidy bliskie Ziemi (dzisiaj)</h2>
            {asteroids.map((asteroid, idx) => (
                <Asteroid key={idx} {...asteroid} />
            ))}
        </div>
    );
}

export default Asteroids;