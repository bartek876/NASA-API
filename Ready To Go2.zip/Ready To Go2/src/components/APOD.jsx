import React from "react";

function APOD({ item }) {
  return (
    <div className="apod-card">
      <h3>{item.title}</h3>
      <p>{item.date}</p>
      {item.media_type === "image" ? (
        <img src={item.url} alt={item.title} />
      ) : (
        <iframe
          title={`NASA Video ${item.date}`}
          src={item.url}
          frameBorder="0"
          allowFullScreen
          width="100%"
          height="400"
        />
      )}
      <p>{item.explanation}</p>
    </div>
  );
}

export default APOD;