import React from "react";

function Asteroid({ name, diameter, speed, distance, hazardous }) {
    return (
        <div className={`asteroid-card ${hazardous ? "asteroid-card--danger" : ""}`}>
            <h4 className="asteroid-card__name">{name}</h4>
            <p className="asteroid-card__data"><strong>Średnica:</strong> {diameter} m</p>
            <p className="asteroid-card__data"><strong>Prędkość:</strong> {speed} km/h</p>
            <p className="asteroid-card__data"><strong>Odległość od Ziemi:</strong> {distance} km</p>
            <p className="asteroid-card__data">
                <strong>Niebezpieczna?</strong> {hazardous ? "TAK" : "Nie"}
            </p>
        </div>
    );
}

export default Asteroid;