import React from "react";
import ReactDOM from "react-dom/client";
import "./scss/main.css"
import "./scss/components/_APODS.scss"
import "./scss/components/_earth_images.scss"
import "./scss/components/_Mars_images.scss"
import "./scss/components/_asteroids.scss"
import "./scss/components/_donkievents.scss"
import "./scss/components/_navigation.scss"
import "./scss/components/_header.scss"
import "./scss/components/_footer.scss"
import "./scss/components/_space-quiz.scss"
import "./scss/_body.scss"




import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Header from "./components/Header";
import APODS from "./components/APODS";
import EarthImages from "./components/EarthImages";
import Footer from "./components/Footer";
import MarsImages from "./components/MarsImages";
import DonkiEvents from "./components/DonkiEvents";
import Asteroids from "./components/Asteroids";
import Quiz from "./components/Quiz";





function Navigation() {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/a1">Randomowe Forografie Obiektów</Link>
          </li>
          <li>
            <Link to="/a2">Dane Asteroidów w kosmosie</Link>
          </li>

          <li>
            <Link to="/a3">Zdjęcia Marsa z łazików</Link>
          </li>
          <li>
            <Link to="/a4">Zjawiska Pogodowe</Link>
          </li>
          <li>
            <Link to="/a5">Zdjęcia satelitarne ziemii</Link>
          </li>
          <li>
            <Link to="/a6">Quiz o kosmosie</Link>
          </li>

        </ul>
      </nav>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Header />
    <BrowserRouter>
      <Navigation />
      <Routes>
        <Route path="/a1" element={<APODS />} />
        <Route path="/a2" element={<Asteroids />} />
        <Route path="/a3" element={<MarsImages />} />
        <Route path="/a4" element={<DonkiEvents />} />
        <Route path="/a5" element={<EarthImages />} />
        <Route path="/a6" element={<Quiz />} />
      </Routes>
    </BrowserRouter>

    <Footer />
  </React.StrictMode>
);
